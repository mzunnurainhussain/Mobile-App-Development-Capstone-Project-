
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
export default function SettingsMenu() {
  return (
    <View style={styles.menu}>
      <Text style={styles.item}>Profile</Text>
      <Text style={styles.item}>Account</Text>
      <Text style={styles.item}>Privacy</Text>
      <Text style={styles.item}>About</Text>
    </View>
  );
}
const styles = StyleSheet.create({
  menu: { padding: 12 },
  item: { paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#eee' },
});
