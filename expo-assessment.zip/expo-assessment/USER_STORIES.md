
# User Stories (9)

1. **As a new user**, I want to create an account with username, email, and password so that I can sign in later.
2. **As a returning user**, I want to log in with my email and password so that I can access saved data.
3. **As a user**, I want to view a home screen with a logo and a list of items so that I can navigate to details.
4. **As a user**, I want to open a detail screen from the home list so that I can see more information about an item.
5. **As a user**, I want to save favorites locally so that they persist between sessions.
6. **As a user**, I want to view data from a remote API so that I can see live updates.
7. **As a user**, I want a settings menu and screen so that I can adjust preferences (e.g., theme).
8. **As a user**, I want to receive a notification so that I am reminded of important updates.
9. **As a user**, I want error feedback on failed signup/login so that I know how to correct issues.
