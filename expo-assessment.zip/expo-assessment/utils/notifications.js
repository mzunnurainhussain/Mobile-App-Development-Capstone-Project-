
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: false, shouldSetBadge: false }),
});
export async function requestPermissionsAsync() {
  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
}
export async function scheduleTestNotification() {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'default', importance: Notifications.AndroidImportance.DEFAULT,
    });
  }
  return Notifications.scheduleNotificationAsync({
    content: { title: 'Test Notification', body: 'This is a test alert.' },
    trigger: { seconds: 2 },
  });
}
