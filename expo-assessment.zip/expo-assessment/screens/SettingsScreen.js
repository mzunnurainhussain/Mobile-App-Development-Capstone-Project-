
import React, { useState } from 'react';
import { View, Text, Switch, StyleSheet } from 'react-native';
export default function SettingsScreen() {
  const [dark, setDark] = useState(false);
  const [notifications, setNotifications] = useState(true);
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Settings</Text>
      <View style={styles.row}><Text style={styles.label}>Dark Mode</Text><Switch value={dark} onValueChange={setDark} /></View>
      <View style={styles.row}><Text style={styles.label}>Notifications</Text><Switch value={notifications} onValueChange={setNotifications} /></View>
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, paddingTop: 40 },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 12 },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12 },
  label: { fontWeight: '600' },
});
