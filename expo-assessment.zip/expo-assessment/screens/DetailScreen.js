
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
export default function DetailScreen({ route }) {
  const { id, title, body } = route.params || {};
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Detail</Text>
      <Text style={styles.label}>ID: {id}</Text>
      <Text style={styles.label}>Title: {title}</Text>
      <Text style={styles.body}>{body}</Text>
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, paddingTop: 40 },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 12 },
  label: { fontWeight: '600', marginBottom: 6 },
  body: { color: '#374151' },
});
