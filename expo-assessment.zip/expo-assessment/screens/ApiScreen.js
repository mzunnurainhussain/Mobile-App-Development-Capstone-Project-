
import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, StyleSheet } from 'react-native';
export default function ApiScreen() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const load = async () => {
    setLoading(true);
    try {
      const res = await fetch('https://jsonplaceholder.typicode.com/posts?_limit=10');
      const json = await res.json();
      setData(json);
    } catch (e) {
      console.warn('API error', e);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); }, []);
  return (
    <View style={styles.container}>
      <Text style={styles.title}>API Data</Text>
      {loading ? <ActivityIndicator /> :
        <FlatList
          data={data}
          keyExtractor={item => String(item.id)}
          renderItem={({ item }) => (<View style={styles.row}><Text style={styles.item}>{item.title}</Text></View>)}
        />
      }
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, paddingTop: 40 },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 12 },
  row: { paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#eee' },
  item: { color: '#111827' },
});
