
import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import { saveItem, getItems, removeItem } from '../storage/localStorage';
export default function ProfileScreen() {
  const [fav, setFav] = useState('');
  const [items, setItems] = useState([]);
  const refresh = async () => setItems(await getItems());
  useEffect(() => { refresh(); }, []);
  const add = async () => { if (!fav.trim()) return; await saveItem({ id: Date.now(), title: fav.trim() }); setFav(''); refresh(); };
  const del = async (id) => { await removeItem(id); refresh(); };
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Profile / Favorites (Local Persistence)</Text>
      <View style={styles.row}>
        <TextInput style={styles.input} placeholder="Add favorite…" value={fav} onChangeText={setFav} />
        <TouchableOpacity style={styles.btn} onPress={add}><Text style={styles.btnText}>Save</Text></TouchableOpacity>
      </View>
      <FlatList
        data={items}
        keyExtractor={x => String(x.id)}
        renderItem={({ item }) => (<TouchableOpacity onLongPress={() => del(item.id)}><Text style={styles.item}>⭐ {item.title}</Text></TouchableOpacity>)}
        ListEmptyComponent={<Text style={{ color: '#6b7280' }}>No favorites yet.</Text>}
      />
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, paddingTop: 40 },
  title: { fontSize: 18, fontWeight: '700', marginBottom: 12 },
  row: { flexDirection: 'row', gap: 8, alignItems: 'center', marginBottom: 12 },
  input: { flex: 1, borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 10 },
  btn: { backgroundColor: '#3478F6', paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8 },
  btnText: { color: 'white', fontWeight: '700' },
  item: { paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#eee' },
});
