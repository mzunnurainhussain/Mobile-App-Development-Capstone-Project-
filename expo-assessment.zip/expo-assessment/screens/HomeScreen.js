
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Image source={require('../assets/icon.png')} style={styles.logo} />
        <TouchableOpacity onPress={() => navigation.navigate('Settings')}>
          <Text style={styles.icon}>⚙️</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.title}>Home</Text>
      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('Detail', { id: 1, title: 'Sample Item', body: 'Detail info here' })}>
        <Text style={styles.cardTitle}>Sample Item →</Text>
        <Text style={styles.cardSub}>Tap to open detail screen</Text>
      </TouchableOpacity>
      <View style={{ height: 12 }} />
      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('API')}>
        <Text style={styles.cardTitle}>Open API Screen →</Text>
        <Text style={styles.cardSub}>Fetch and display remote data</Text>
      </TouchableOpacity>
      <View style={{ height: 12 }} />
      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('Profile')}>
        <Text style={styles.cardTitle}>Profile / Favorites →</Text>
        <Text style={styles.cardSub}>Persistence with AsyncStorage</Text>
      </TouchableOpacity>
      <View style={{ height: 12 }} />
      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('Notifications')}>
        <Text style={styles.cardTitle}>Notifications →</Text>
        <Text style={styles.cardSub}>Configure & test a local notification</Text>
      </TouchableOpacity>
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, paddingTop: 40 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  logo: { width: 32, height: 32 },
  icon: { fontSize: 22 },
  title: { fontSize: 22, fontWeight: '700', marginVertical: 16 },
  card: { borderWidth: 1, borderColor: '#e5e7eb', borderRadius: 12, padding: 14 },
  cardTitle: { fontSize: 16, fontWeight: '700' },
  cardSub: { color: '#6b7280', marginTop: 4 },
});
