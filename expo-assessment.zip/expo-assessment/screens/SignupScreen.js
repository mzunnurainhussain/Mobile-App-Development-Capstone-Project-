
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
export default function SignupScreen({ navigation }) {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const onSignup = () => {
    if (!username || !email.includes('@') || password.length < 6) {
      Alert.alert('Signup Error', 'Please provide a username, valid email, and password (min 6 chars).');
      return;
    }
    Alert.alert('Success', 'Account created! You can log in now.');
    navigation.navigate('Login');
  };
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Sign Up</Text>
      <TextInput placeholder="Username" style={styles.input} value={username} onChangeText={setUsername} />
      <TextInput placeholder="Email" style={styles.input} value={email} onChangeText={setEmail} />
      <TextInput placeholder="Password" secureTextEntry style={styles.input} value={password} onChangeText={setPassword} />
      <TouchableOpacity style={styles.btn} onPress={onSignup}><Text style={styles.btnText}>Sign Up</Text></TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('Login')}>
        <Text style={styles.link}>Have an account? Login</Text>
      </TouchableOpacity>
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: 'center' },
  title: { fontSize: 24, fontWeight: '700', marginBottom: 16 },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, marginBottom: 10 },
  btn: { backgroundColor: '#111827', padding: 14, borderRadius: 8, marginTop: 4 },
  btnText: { color: 'white', textAlign: 'center', fontWeight: '700' },
  link: { marginTop: 12, color: '#3478F6', textAlign: 'center' },
});
