
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { requestPermissionsAsync, scheduleTestNotification } from '../utils/notifications';
export default function NotificationsScreen() {
  const [granted, setGranted] = useState(false);
  const onConfigure = async () => {
    const ok = await requestPermissionsAsync();
    setGranted(ok);
    Alert.alert('Notifications', ok ? 'Permissions granted' : 'Permissions denied');
  };
  const onTest = async () => {
    try { await scheduleTestNotification(); Alert.alert('Notification', 'Test notification scheduled'); }
    catch (e) { Alert.alert('Error', 'Failed to schedule'); }
  };
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Notifications</Text>
      <TouchableOpacity style={styles.btn} onPress={onConfigure}><Text style={styles.btnText}>Configure</Text></TouchableOpacity>
      <TouchableOpacity style={styles.btn} onPress={onTest}><Text style={styles.btnText}>Send Test Alert</Text></TouchableOpacity>
      <Text style={{ marginTop: 8 }}>Granted: {String(granted)}</Text>
    </View>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, paddingTop: 40 },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 12 },
  btn: { backgroundColor: '#111827', padding: 14, borderRadius: 8, marginTop: 8 },
  btnText: { color: 'white', textAlign: 'center', fontWeight: '700' },
});
