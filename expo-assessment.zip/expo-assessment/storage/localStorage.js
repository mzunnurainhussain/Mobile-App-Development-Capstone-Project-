
import AsyncStorage from '@react-native-async-storage/async-storage';
const KEY = '@favorites';
export async function getItems() {
  try { const raw = await AsyncStorage.getItem(KEY); return raw ? JSON.parse(raw) : []; }
  catch (e) { return []; }
}
export async function saveItem(item) {
  const items = await getItems();
  const next = [item, ...items];
  await AsyncStorage.setItem(KEY, JSON.stringify(next));
}
export async function removeItem(id) {
  const items = await getItems();
  const next = items.filter(x => x.id !== id);
  await AsyncStorage.setItem(KEY, JSON.stringify(next));
}
